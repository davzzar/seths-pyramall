1. Before the game is started, the controllers of the players must be connected.

1. The players are moved left and right with the left joy-stick.

1. The players jump with A.

1. To start the game, all of the players must press A.

1. The goal of the game is to reach the goal at the top.

1. The sand doesn't currently affect the player.
