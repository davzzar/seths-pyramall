Make sure the gamepad is connected to the PC.
Start the game and control the smiley using the gamepad.
Enjoy infinite-jump ability and perfectly wonky physics. :)

Controlls:
Left thumbstick		Horizontal movement		
A					Jump